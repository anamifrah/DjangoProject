class DonationError(Exception):
    pass
